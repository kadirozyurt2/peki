const Invite = () => {
  return (
    <>
      <div className="footer-top-text">
        <h5>
          Start <span>your</span> journey
        </h5>
        <p>
          Our customer support and extensive library of best practices, guides
        </p>
      </div>
    </>
  );
};

export default Invite;
