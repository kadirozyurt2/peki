const Form = () => {
  return (
    <>
      <div className="footer-mail-adress-area">
        <form action>
          <div className="form-area">
            <input placeholder="Your mail address" type="text" />
            <button>Get Started</button>
          </div>
        </form>
      </div>
    </>
  );
};

export default Form;
